module.exports = {
	urlSubjectViews: 'mongodb://localhost:27017/donorschoose',

}
